#include "app_mems.h"
#include "main.h"
#include "iks01a2_motion_sensors.h"
#include "stm32f4xx_nucleo.h"
#include "pwm_control.h"
#include "motion_fx.h"

/* Private variables ---------------------------------------------------------*/

/* Private function prototypes -----------------------------------------------*/
static IKS01A2_MOTION_SENSOR_Axes_t Accelero_Sensor_Handler(uint32_t Instance);
static IKS01A2_MOTION_SENSOR_Axes_t Gyro_Sensor_Handler(uint32_t Instance);
static IKS01A2_MOTION_SENSOR_Axes_t Magneto_Sensor_Handler(uint32_t Instance);
static void MX_IKS01A2_DataLogTerminal_Init(void);


IKS01A2_MOTION_SENSOR_Axes_t acceleration;
IKS01A2_MOTION_SENSOR_Axes_t angular_velocity;
IKS01A2_MOTION_SENSOR_Axes_t magnetic_field;
MFX_input_t data_in;
MFX_output_t data_out;


#define MOTION_FX_ENGINE_DELTATIME  0.1f
float delta_time = MOTION_FX_ENGINE_DELTATIME;
static MFXState_t mfxstate;
volatile uint8_t control_flag;



void MX_MotionFX_Init(void) {
    MFX_knobs_t iKnobs;
    MotionFX_initialize(&mfxstate);
    MotionFX_enable_9X(&mfxstate, 1);
    MotionFX_getKnobs(&mfxstate, &iKnobs);
    MotionFX_setKnobs(&mfxstate, &iKnobs);
}



void TIM3_IRQHandler(void)
{

  HAL_TIM_IRQHandler(&htim3);

  /* USER CODE BEGIN TIM3_IRQn 1 */
  acceleration = Accelero_Sensor_Handler(IKS01A2_LSM6DSL_0);
  angular_velocity = Gyro_Sensor_Handler(IKS01A2_LSM6DSL_0);
  magnetic_field = Magneto_Sensor_Handler(IKS01A2_LSM303AGR_MAG_0);


  data_in.acc[0] = (acceleration.x -13);
  data_in.acc[1] = (acceleration.y +22);
  data_in.acc[2] = (acceleration.z -1016);

  data_in.gyro[0] = (angular_velocity.x +280);
  data_in.gyro[1] = (angular_velocity.y +3430);
  data_in.gyro[2] = (angular_velocity.z +770);

  data_in.mag[0] = magnetic_field.x - 375;
  data_in.mag[1] = magnetic_field.y + 360;
  data_in.mag[2] = magnetic_field.z + 560;

  MotionFX_propagate(&mfxstate, &data_out, &data_in, &delta_time);
  MotionFX_update(&mfxstate, &data_out, &data_in, &delta_time, NULL);
  control_flag = 1;
}

void MX_MEMS_Init(void)
{

  MX_IKS01A2_DataLogTerminal_Init();
}

void MX_MEMS_Process(void)
{
  MX_IKS01A2_DataLogTerminal_Process();
}

void MX_IKS01A2_DataLogTerminal_Init(void)
{
  IKS01A2_MOTION_SENSOR_Init(IKS01A2_LSM6DSL_0, MOTION_ACCELERO | MOTION_GYRO);
  IKS01A2_MOTION_SENSOR_Init(IKS01A2_LSM303AGR_ACC_0, MOTION_ACCELERO);
  IKS01A2_MOTION_SENSOR_Init(IKS01A2_LSM303AGR_MAG_0, MOTION_MAGNETO);


}

static IKS01A2_MOTION_SENSOR_Axes_t Accelero_Sensor_Handler(uint32_t Instance) {
	IKS01A2_MOTION_SENSOR_Axes_t acceleration;
    if (IKS01A2_MOTION_SENSOR_GetAxes(Instance, MOTION_ACCELERO, &acceleration) == 0)
      {
    	return acceleration;
      }
}

static IKS01A2_MOTION_SENSOR_Axes_t Gyro_Sensor_Handler(uint32_t Instance) {
	IKS01A2_MOTION_SENSOR_Axes_t angular_velocity;

    if (IKS01A2_MOTION_SENSOR_GetAxes(Instance, MOTION_GYRO, &angular_velocity) == 0)
    	{
        return angular_velocity;
    	}
}
static IKS01A2_MOTION_SENSOR_Axes_t Magneto_Sensor_Handler(uint32_t Instance) {
	IKS01A2_MOTION_SENSOR_Axes_t magnetic_field;

    if (IKS01A2_MOTION_SENSOR_GetAxes(Instance, MOTION_MAGNETO, &magnetic_field) == 0)
    {
        return magnetic_field;
    }
}
