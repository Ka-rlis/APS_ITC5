// pwm_control.h

#include "stm32f4xx_hal.h"
#include "motion_fx.h"
#ifndef PWM_CONTROL_H
#define PWM_CONTROL_H


int PWM_GyroMapping(int gyroZAxisValue);
float Gyro_Data_Integration(int gyroZAxisValue);
int get_data(data_in);



#endif // PWM_CONTROL_H

